# lab1

使用`g++ e.cc -fopenmp -lgmpxx -lgmp -o e`生成可执行文件
